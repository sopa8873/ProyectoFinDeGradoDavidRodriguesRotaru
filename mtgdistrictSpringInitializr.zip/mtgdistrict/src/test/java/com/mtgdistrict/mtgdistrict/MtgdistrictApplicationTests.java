package com.mtgdistrict.mtgdistrict;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MtgdistrictApplicationTests {

	@Test
	void contextLoads() {
	}

}
